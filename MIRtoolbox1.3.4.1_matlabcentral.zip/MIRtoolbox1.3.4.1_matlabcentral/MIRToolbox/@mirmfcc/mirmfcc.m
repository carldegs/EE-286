function varargout = mirmfcc(orig,varargin)
%   c = mirmfcc(a) finds the Mel frequency cepstral coefficients (ceps),
%       a numerical description of the spectrum envelope.

%web('http://www.jyu.fi/hum/laitokset/musiikki/en/research/coe/materials/mirtoolbox')
error('SORRY! For legal reasons, mirmfcc is not included in MIRtoolbox Matlab Central Version. MIRtoolbox Complete version is freely available from the official MIRtoolbox website.')